import enum


class MsPayment(enum.Enum):

    # Consume
    MsPaymentCapturePayment = "MsPaymentCapturePayment"


class MsMobile(enum.Enum):
    #  Produce
    MsMobileReserveNow_For_MsPaymentRes = "MsMobileReserveNow_For_MsPaymentRes"

    # Consume
    MsMobileReserveNow_For_MsPaymentReq = "MsMobileReserveNow_For_MsPaymentReq"


class Common(enum.Enum):

    # Consume
    CommonSendAlert = "CommonSendAlert"
    CommonCreateTenant = "CommonCreateTenant"


class MsInvoice(enum.Enum):
    #  Produce
    MsInvoiceCheckOrder_For_MsPaymentRes = (
        "MsInvoiceCheckOrder_For_MsPaymentRes"
    )

    # Consume
    MsInvoiceCheckOrder_For_MsPaymentReq = (
        "MsInvoiceCheckOrder_For_MsPaymentReq"
    )

    MsInvoiceSendB2BInvoice = "MsInvoiceSendB2BInvoice"
    MsInvoiceSendB2CInvoice = "MsInvoiceSendB2CInvoice"
    MsInvoiceUpdateMobileCarrier = "MsInvoiceUpdateMobileCarrier"


class OcppLogic(enum.Enum):
    #  Produce
    OcppLogicUpdateConnectionStatus = "OcppLogicUpdateConnectionStatus"

    OcppLogicCertificateSignedRes = "OcppLogicCertificateSignedRes"
    OcppLogicSignedUpdateFirmwareRes = "OcppLogicSignedUpdateFirmwareRes"
    OcppLogicChangeConfigurationRes = "OcppLogicChangeConfigurationRes"
    OcppLogicGetConfigurationRes = "OcppLogicGetConfigurationRes"
    OcppLogicSendResetRes = "OcppLogicSendResetRes"
    OcppLogicClearCacheRes = "OcppLogicClearCacheRes"
    OcppLogicSendLocalListRes = "OcppLogicSendLocalListRes"
    OcppLogicGetLocalListRes = "OcppLogicGetLocalListRes"
    OcppLogicUnlockConnectorRes = "OcppLogicUnlockConnectorRes"
    OcppLogicTriggerMessageRes = "OcppLogicTriggerMessageRes"
    OcppLogicChangeAvailabilityRes = "OcppLogicChangeAvailabilityRes"
    OcppLogicReserveNowRes = "OcppLogicReserveNowRes"
    OcppLogicCancelReservationRes = "OcppLogicCancelReservationRes"
    OcppLogicRemoteStartRes = "OcppLogicRemoteStartRes"
    OcppLogicRemoteStopRes = "OcppLogicRemoteStopRes"
    OcppLogicSetChargingProfileRes = "OcppLogicSetChargingProfileRes"
    OcppLogicGetCompositeScheduleRes = "OcppLogicGetCompositeScheduleRes"
    OcppLogicClearChargingProfileRes = "OcppLogicClearChargingProfileRes"
    OcppLogicUpdateFirmwareRes = "OcppLogicUpdateFirmwareRes"
    OcppLogicExtendedTriggerMessageRes = "OcppLogicExtendedTriggerMessageRes"
    OcppLogicGetInstalledCertificateIdsRes = (
        "OcppLogicGetInstalledCertificateIdsRes"
    )
    OcppLogicDeleteCertificateRes = "OcppLogicDeleteCertificateRes"
    OcppLogicInstallCertificateRes = "OcppLogicInstallCertificateRes"
    OcppLogicGetLogRes = "OcppLogicGetLogRes"
    OcppLogicGetDiagnosticsRes = "OcppLogicGetDiagnosticsRes"
    OcppLogicDataTransferRes = "OcppLogicDataTransferRes"
    OcppLogicCustomerInformationRes = (
        "OcppLogicCustomerInformationRes"  # added
    )
    OcppLogicGetBaseReportRes = "OcppLogicGetBaseReportRes"  # added
    OcppLogicGetTransactionStatusRes = (
        "OcppLogicGetTransactionStatusRes"  # added
    )
    OcppLogicSendDataTransferRes = "OcppLogicSendDataTransferRes"  # added
    OcppLogicSetNetworkProfileRes = "OcppLogicSetNetworkProfileRes"  # added

    OcppLogicStartTransactionRes = "OcppLogicStartTransactionRes"
    OcppLogicStopTransactionRes = "OcppLogicStopTransactionRes"
    OcppLogicStatusNotificationRes = "OcppLogicStatusNotificationRes"
    OcppLogicMeterValuesRes = "OcppLogicMeterValuesRes"

    # Consume
    OcppLogicCertificateSignedReq = "OcppLogicCertificateSignedReq"
    OcppLogicSignedUpdateFirmwareReq = "OcppLogicSignedUpdateFirmwareReq"
    OcppLogicChangeConfigurationReq = "OcppLogicChangeConfigurationReq"
    OcppLogicGetConfigurationReq = "OcppLogicGetConfigurationReq"
    OcppLogicSendResetReq = "OcppLogicSendResetReq"  # edited
    OcppLogicClearCacheReq = "OcppLogicClearCacheReq"
    OcppLogicSendLocalListReq = "OcppLogicSendLocalListReq"
    OcppLogicGetLocalListReq = "OcppLogicGetLocalListReq"
    OcppLogicUnlockConnectorReq = "OcppLogicUnlockConnectorReq"
    OcppLogicTriggerMessageReq = "OcppLogicTriggerMessageReq"
    OcppLogicChangeAvailabilityReq = "OcppLogicChangeAvailabilityReq"
    OcppLogicReserveNowReq = "OcppLogicReserveNowReq"  # edited
    OcppLogicCancelReservationReq = "OcppLogicCancelReservationReq"  # edited
    OcppLogicRemoteStartReq = "OcppLogicRemoteStartReq"
    OcppLogicRemoteStopReq = "OcppLogicRemoteStopReq"
    OcppLogicSetChargingProfileReq = "OcppLogicSetChargingProfileReq"
    OcppLogicGetCompositeScheduleReq = "OcppLogicGetCompositeScheduleReq"
    OcppLogicClearChargingProfileReq = "OcppLogicClearChargingProfileReq"
    OcppLogicUpdateFirmwareReq = "OcppLogicUpdateFirmwareReq"
    OcppLogicExtendedTriggerMessageReq = "OcppLogicExtendedTriggerMessageReq"
    OcppLogicGetInstalledCertificateIdsReq = (
        "OcppLogicGetInstalledCertificateIdsReq"
    )
    OcppLogicDeleteCertificateReq = "OcppLogicDeleteCertificateReq"
    OcppLogicInstallCertificateReq = "OcppLogicInstallCertificateReq"
    OcppLogicGetLogReq = "OcppLogicGetLogReq"
    OcppLogicGetDiagnosticsReq = "OcppLogicGetDiagnosticsReq"
    OcppLogicDataTransferReq = "OcppLogicDataTransferReq"
    OcppLogicCustomerInformationReq = (
        "OcppLogicCustomerInformationReq"  # added
    )
    OcppLogicGetBaseReportReq = "OcppLogicGetBaseReportReq"  # added
    OcppLogicGetTransactionStatusReq = (
        "OcppLogicGetTransactionStatusReq"  # added
    )
    OcppLogicSendDataTransferReq = "OcppLogicSendDataTransferReq"  # added
    OcppLogicSetNetworkProfileReq = "OcppLogicSetNetworkProfileReq"  # added


class MsChargerManagement(enum.Enum):
    #  Produce
    MsChargerManagementAddNewEvcReq = "MsChargerManagementAddNewEvcReq"

    MsChargerManagementEvc = "MsChargerManagementEvc"
    MsChargerManagementStation = "MsChargerManagementStation"
    MsChargerManagementRfidStatus = "MsChargerManagementRfidStatus"
    MsChargerManagementAgencyPremise = "MsChargerManagementAgencyPremise"

    # Consume
    MsChargerManagementAddNewEvcRes = "MsChargerManagementAddNewEvcRes"


class MsRfidManagement(enum.Enum):
    CreateVehicleRFID = "CreateVehicleRFID"
    UpdateVehicleRFID = "UpdateVehicleRFID"
    DeleteVehicleRFID = "DeleteVehicleRFID"
    SwapVehicleRFID = "SwapVehicleRFID"
    AuthenticateUserReq = "AuthenticateUserReq"
    AuthenticateUserRes = "AuthenticateUserRes"
    CheckvehicleRFIDStatusReq = "CheckvehicleRFIDStatusReq"
    CheckvehicleRFIDStatusRes = "CheckvehicleRFIDStatusRes"


class MsAdminManagement(enum.Enum):
    AdminCreate = "AdminCreate"
    AdminUpdateStatus = "AdminUpdateStatus"
    AdminDelete = "AdminDelete"
    AdminUpdateRole = "AdminUpdateRole"
    CheckAdminExistsReq = "CheckAdminExistsReq"
    CheckAdminExistsRes = "CheckAdminExistsRes"
    ListAdminsReq = "ListAdminsReq"
    ListAdminsRes = "ListAdminsRes"


class MsAuthenticationServer(enum.Enum):
    CheckIDTokenValidityReq = "CheckIDTokenValidityReq"
    CheckIDTokenValidityRes = "CheckIDTokenValidityRes"
    CheckIDTokenExistsReq = "CheckIDTokenExistsReq"
    CheckIDTokenExistsRes = "CheckIDTokenExistsRes"


class MsSmartCharging(enum.Enum):
    MsSmartChargingStationLoad = "MsSmartChargingStationLoad"
